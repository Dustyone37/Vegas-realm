const express = require('express');
const router = express.Router();

// Simulated NFT Inventory
const nftAssets = {
  'user_001': [
    { name: 'Vegas Chain', tokenId: '0xabc123', network: 'Polygon' },
    { name: 'Diamond Dice', tokenId: '0xdef456', network: 'Ethereum' }
  ]
};

router.get('/:userId', (req, res) => {
  const userAssets = nftAssets[req.params.userId] || [];
  res.json({ inventory: userAssets });
});

module.exports = router;