function runTrial({ defendant, history }) {
  const crimes = history.length;
  const decision = crimes > 3 ? 'Guilty' : 'Plea Deal';
  const sentence = decision === 'Guilty' ? `${crimes * 30} seconds` : 'Fine issued';
  return {
    decision,
    sentence,
    judge: 'AI Judge #42',
    trialSummary: `Defendant had ${crimes} crimes on record.`
  };
}

module.exports = { runTrial };