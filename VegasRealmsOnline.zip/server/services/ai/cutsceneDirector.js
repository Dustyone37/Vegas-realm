function generateCutscene(type, context) {
  switch (type) {
    case 'arrest':
      return `🚓 Police cutscene: ${context.player} caught fleeing the scene.`;
    case 'trial':
      return `⚖️ Courtroom cutscene: ${context.player} faces Judge AI-42 for ${context.crime}.`;
    case 'release':
      return `🚪 Release cutscene: ${context.player} walks free after serving time.`;
    default:
      return '🎥 Generic transition scene.';
  }
}
module.exports = { generateCutscene };