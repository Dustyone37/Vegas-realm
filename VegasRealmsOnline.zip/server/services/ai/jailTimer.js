class JailTimer {
  constructor(seconds) {
    this.seconds = seconds;
    this.remaining = seconds;
    this.active = false;
  }
  start() {
    this.active = true;
    const interval = setInterval(() => {
      this.remaining--;
      if (this.remaining <= 0) {
        this.active = false;
        clearInterval(interval);
      }
    }, 1000);
  }
}
module.exports = JailTimer;