const lobbies = {};

function createLobby(hostId) {
  const lobbyId = 'lobby_' + Math.random().toString(36).substring(2, 8);
  lobbies[lobbyId] = { hostId, players: [hostId] };
  return { lobbyId, lobby: lobbies[lobbyId] };
}

function joinLobby(lobbyId, playerId) {
  if (lobbies[lobbyId]) {
    lobbies[lobbyId].players.push(playerId);
    return lobbies[lobbyId];
  }
  throw new Error("Lobby not found");
}

module.exports = { createLobby, joinLobby };