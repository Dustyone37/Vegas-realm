const jobs = [
  { id: 'job_001', title: 'Pit Boss', reward: 500, type: 'casino' },
  { id: 'job_002', title: 'Debt Collector', reward: 800, type: 'chaos' },
  { id: 'job_003', title: 'VIP Host', reward: 1000, type: 'prestige' }
];

function getAvailableJobs() {
  return jobs;
}

function completeJob(userId, jobId) {
  const job = jobs.find(j => j.id === jobId);
  if (!job) throw new Error('Job not found');
  return { userId, job, payout: job.reward, status: 'completed' };
}

module.exports = { getAvailableJobs, completeJob };