const contracts = [];

function signContract({ userId, contractType, terms }) {
  const contractId = 'contract_' + Math.random().toString(36).substring(2, 10);
  const contract = {
    contractId,
    userId,
    contractType,
    terms,
    signedAt: new Date().toISOString()
  };
  contracts.push(contract);
  return contract;
}

function getUserContracts(userId) {
  return contracts.filter(c => c.userId === userId);
}

module.exports = { signContract, getUserContracts };