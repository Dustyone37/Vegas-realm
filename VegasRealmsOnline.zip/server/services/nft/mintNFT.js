function mintNFT(userId, itemName) {
  return {
    tokenId: '0x' + Math.random().toString(16).slice(2, 10),
    owner: userId,
    asset: itemName,
    network: 'Polygon',
    mintedAt: new Date().toISOString()
  };
}
module.exports = { mintNFT };