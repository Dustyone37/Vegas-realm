function spinSlot() {
  const reels = [
    ['🍒', '🍋', '🔔', '7️⃣'],
    ['🍒', '🍋', '🔔', '7️⃣'],
    ['🍒', '🍋', '🔔', '7️⃣']
  ];
  const result = reels.map(reel => reel[Math.floor(Math.random() * reel.length)]);
  const win = (result[0] === result[1] && result[1] === result[2]);
  return { result, win, payout: win ? 100 : 0 };
}
module.exports = { spinSlot };