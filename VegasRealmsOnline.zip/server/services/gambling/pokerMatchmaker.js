const pokerRooms = [];

function joinPokerRoom(userId) {
  let room = pokerRooms.find(r => r.players.length < 6);
  if (!room) {
    room = { id: 'room_' + Math.random().toString(36).slice(2, 8), players: [] };
    pokerRooms.push(room);
  }
  room.players.push(userId);
  return room;
}

function getRoomState(roomId) {
  return pokerRooms.find(r => r.id === roomId);
}

module.exports = { joinPokerRoom, getRoomState };