function calculateOdds(teamA, teamB) {
  const base = 0.5;
  const modifier = teamA.rating / (teamA.rating + teamB.rating);
  return { teamA: (base * modifier).toFixed(2), teamB: (base * (1 - modifier)).toFixed(2) };
}
module.exports = { calculateOdds };