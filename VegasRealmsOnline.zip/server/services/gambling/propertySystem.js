const properties = [];

function listProperty(ownerId, name, type, rent) {
  const id = 'prop_' + Math.random().toString(36).substring(2, 10);
  const property = { id, ownerId, name, type, rent, listed: true };
  properties.push(property);
  return property;
}

function getProperties() {
  return properties.filter(p => p.listed);
}

function buyProperty(propertyId, buyerId) {
  const prop = properties.find(p => p.id === propertyId);
  if (!prop || !prop.listed) throw new Error('Property not available');
  prop.ownerId = buyerId;
  prop.listed = false;
  return prop;
}

module.exports = { listProperty, getProperties, buyProperty };