function evaluateHand(hand) {
  const values = hand.map(card => card.value);
  const unique = [...new Set(values)];
  return unique.length === 2 ? 'Full House or Four of a Kind' : 'Other';
}
module.exports = { evaluateHand };