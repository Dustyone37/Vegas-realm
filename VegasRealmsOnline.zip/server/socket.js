const { Server } = require("socket.io");

function initSocket(server) {
  const io = new Server(server, { cors: { origin: "*" } });

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_lobby', ({ lobbyId, userId }) => {
      socket.join(lobbyId);
      io.to(lobbyId).emit('lobby_update', { message: `${userId} joined.` });
    });

    socket.on('place_bet', (data) => {
      const { lobbyId, userId, amount } = data;
      io.to(lobbyId).emit('bet_placed', { userId, amount });
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  return io;
}

module.exports = { initSocket };