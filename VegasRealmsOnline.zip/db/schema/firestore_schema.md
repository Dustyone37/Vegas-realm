# Firestore Schema

## users/
- id (string, UID)
- username (string)
- email (string)
- walletBalance (number)
- vegasStatus (string) – ['Bronze', 'Silver', 'Gold', 'Legend']
- nftInventory (array of object)

## bets/
- id (string)
- userId (ref: users)
- type (string) – ['slot', 'poker', 'sportsbook']
- amount (number)
- result (string)
- payout (number)
- createdAt (timestamp)

## properties/
- id (string)
- ownerId (ref: users)
- name (string)
- type (string) – ['penthouse', 'casino', 'club']
- rent (number)
- listed (boolean)
