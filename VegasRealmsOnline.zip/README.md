# Vegas Realms Online™

A real-money, real-time multiplayer casino MMORPG built with Node.js, React, Firebase, and Unreal Engine integration.

## Run Instructions
- Backend: `cd server && npm install && node index.js`
- Frontend: `cd client && npm install && npm start`

VS Code Workspace included.
