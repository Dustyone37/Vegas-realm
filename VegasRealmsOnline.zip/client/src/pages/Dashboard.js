import React, { useEffect, useState } from 'react';
import { getBalance, spinSlot } from '../services/api';

const Dashboard = () => {
  const [balance, setBalance] = useState(0);
  const [slotResult, setSlotResult] = useState(null);

  useEffect(() => {
    getBalance().then(setBalance);
  }, []);

  const handleSlotSpin = async () => {
    const res = await spinSlot();
    setSlotResult(res);
    setBalance(prev => res.newBalance);
  };

  return (
    <div className="p-8">
      <h1 className="text-xl">Player Dashboard</h1>
      <p>Balance: ${balance}</p>
      <button className="bg-green-600 text-white px-4 py-2 mt-2" onClick={handleSlotSpin}>
        Spin Slot
      </button>
      {slotResult && (
        <div>
          <p>Result: {slotResult.result.join(' | ')}</p>
          <p>{slotResult.win ? `You won $${slotResult.payout}` : "No win this time"}</p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;