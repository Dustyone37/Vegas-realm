import axios from 'axios';
const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const getBalance = async () => {
  const { data } = await API.get('/wallet/balance');
  return data.balance;
};

export const spinSlot = async () => {
  const { data } = await API.post('/bet/slot');
  return data;
};