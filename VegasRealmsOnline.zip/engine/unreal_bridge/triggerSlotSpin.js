// Unreal Engine sends POST request here when player spins in 3D world
const express = require('express');
const router = express.Router();
const { spinSlot } = require('../../server/services/gambling/slotEngine');

router.post('/trigger/spin-slot', (req, res) => {
  const result = spinSlot();
  res.json(result);
});

module.exports = router;