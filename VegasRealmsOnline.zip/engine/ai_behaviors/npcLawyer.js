class NPCLawyer {
  constructor(name) {
    this.name = name;
  }
  argueCase(playerHistory) {
    if (playerHistory.crimes < 3) return 'Plea bargain';
    return 'Prepare for trial';
  }
}
module.exports = NPCLawyer;