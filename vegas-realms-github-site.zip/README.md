
# Vegas Realms Online

Welcome to the official investor landing page for **Vegas Realms Online**, developed by HanksTech Ventures.

This project is a revolutionary online gambling RPG that combines the thrill of Vegas with immersive multiplayer gameplay. Players can create avatars, place real-money bets, socialize, and even own virtual property in a digital Las Vegas-style environment.

## 📂 Included Materials

- `index.html` – The interactive investor landing page
- `Vegas_Realms_Executive_Summary.pdf`
- `Vegas_Realms_OnePage_Pitch.pdf`
- `Vegas_Realms_Investor_Deck_Background_Final.pptx`
- `Vegas_Realms_Press_Release.pdf`

## 📈 Investment Opportunity

We are currently raising **$1.5M** in pre-seed funding. Download our deck or contact us below for a private demo.

## 📬 Contact

**Dustin Hanks**  
📧 dusty.hanks11@gmail.com  
📞 281-543-0267  
