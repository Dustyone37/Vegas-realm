import React, { useState } from 'react';

function App() {
    const [slotResult, setSlotResult] = useState(null);

    const playSlot = async () => {
        const res = await fetch('/game/slot');
        const data = await res.json();
        setSlotResult(data);
    };

    return (
        <div>
            <h1>Vegas Realms Online</h1>
            <button onClick={playSlot}>Spin Slot</button>
            {slotResult && (
                <div>
                    <p>Reels: {slotResult.reels.join(' ')}</p>
                    <p>{slotResult.isWin ? "🎉 You Win!" : "Try Again"}</p>
                </div>
            )}
        </div>
    );
}

export default App;
