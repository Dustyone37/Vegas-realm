export default async function runTestScenario() {
  console.log("Running VegasRealms test scenario 01...");
  await simulatePlayerLogin("user001");
  await simulateBet("user001", "match001", "Tigers", 100);
  await triggerChaosRobbery();
  await simulateCourtTrial("user001");
  console.log("Test complete.");
}
