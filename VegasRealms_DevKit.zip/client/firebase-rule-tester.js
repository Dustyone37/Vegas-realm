// Simulates read/write auth check for Firebase rules testing
function canRead(userId, resourceOwnerId) {
    return userId === resourceOwnerId;
}

function canWrite(authenticated) {
    return !!authenticated;
}

module.exports = { canRead, canWrite };
