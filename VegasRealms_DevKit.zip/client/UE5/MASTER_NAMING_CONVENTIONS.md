# Vegas Realms Online - Master Asset Folder & Naming Conventions

## 📁 Master Asset Directory
All UE5 game assets should be organized under the following hierarchy:
```
/Content/VegasRealms/
├── Meshes/
│   ├── SlotMachines/
│   ├── Tables/
│   ├── Accessories/
├── Blueprints/
│   ├── Gameplay/
│   ├── Triggers/
├── Animations/
├── Textures/
├── Materials/
├── Audio/
├── FX/
├── UI/
```

---

## 🏷️ Naming Conventions

**Meshes:**
- Static Mesh: `SM_[ObjectName]`
- Example: `SM_SlotMachine_Classic`, `SM_PokerTable_VIP`

**Blueprints:**
- Actor Blueprint: `BP_[ObjectName]`
- Trigger Box: `BP_[ObjectName]Trigger`
- Example: `BP_PokerTable`, `BP_BetZoneTrigger`

**Animations:**
- Animation: `ANIM_[ActionDescription]`
- Example: `ANIM_DealerShuffle`, `ANIM_SlotReelSpin`

**Textures:**
- Diffuse: `T_[ObjectName]_D`
- Normal: `T_[ObjectName]_N`
- Roughness: `T_[ObjectName]_R`
- Emissive: `T_[ObjectName]_E`

**Materials:**
- Material: `M_[ObjectName]`
- Instance: `MI_[MaterialInstanceName]`

---

## 🎯 Collision Setup
1. Enable **auto-generated collision** during import for static meshes
2. Manually assign `Simple Collision` in Static Mesh Editor if needed
3. Use custom collision presets in `Project Settings → Collision → Object Channels` for:
   - Interactables
   - Tables
   - NPC Zones

## ✔ Best Practices
- Keep all assets modular
- Reuse textures/materials when possible
- Apply sockets for seats, wheels, cards, and dealer positions
- Group table sets as `Blueprint + StaticMesh + FX`

