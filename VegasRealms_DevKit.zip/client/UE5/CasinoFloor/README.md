# Casino Floor Mockup — Vegas Realms Online (UE5)

## Overview
This folder contains a scaffolded Unreal Engine 5 casino floor map and basic blueprints for gameplay areas.

## Contents
- **CasinoFloor.umap**: Top-down placeholder for slot, table games, sportsbook, and VIP areas
- **Blueprints**:
  - BP_SlotMachine
  - BP_PokerTable
  - BP_PlayerSpawner
  - BP_LightingSystem
  - BP_ZoneTrigger

## Instructions
1. Open UE5 and create a new project (or open existing).
2. Copy contents of `client/UE5/CasinoFloor/` into your UE project `/Content/` folder.
3. Open `CasinoFloor.umap` and start assigning assets to Blueprints or import your own meshes.
4. Use the Blueprints as logic anchors — update visuals in UE5 Editor.

Ready for modular expansion.

— End of File —


---

## 🃏 Table Game Assets & Logic

### Imported Meshes:
- SM_PokerTable.fbx
- SM_BlackjackTable.fbx
- SM_PokerChips.fbx
- SM_PlayingCards.fbx

### Blueprint Triggers:
- BP_TableSeatTrigger → enables player seating
- BP_BetZoneTrigger → activates betting UI on enter

## Setup Instructions:
1. Add table meshes into floor layout via the editor
2. Place BP_TableSeatTrigger around each seat node
3. Attach BP_BetZoneTrigger in front of player positions
4. Connect interaction logic using Blueprint → "OnOverlap" events



---

## 🎯 Roulette & Dice Assets

### Imported Meshes:
- SM_RouletteTable.fbx
- SM_RouletteWheel.fbx
- SM_RouletteBall.fbx
- SM_Dice.fbx

### Blueprints:
- BP_RouletteSpinTrigger → spins wheel on interact
- BP_DiceRollTrigger → triggers dice roll animation and random output

## Setup Instructions:
1. Place roulette table/wheel/ball as grouped assets
2. Add BP_RouletteSpinTrigger collision box around wheel
3. Set dice as interactive mesh with BP_DiceRollTrigger
4. Use event dispatchers to link spins/rolls with random result generators



---

## 🧍 In-Game Player Character (Leisure Suit Larry Style)

### Character Files:
- CH_Player_Larry.fbx → stylized player model
- ANIM_LarryIdle.fbx → idle animation
- ANIM_LarryWalk.fbx → walking loop
- ANIM_LarryEmoteThumbsUp.fbx → emote gesture

### Blueprint:
- BP_Character_Larry → third-person blueprint with custom mesh and idle/walk/emote states

## Setup Instructions:
1. Import character mesh and animations as skeletal
2. Configure Animation Blueprint with state machine:
   - Idle ↔ Walk ↔ Emote
3. Spawn character from PlayerStart or use `BP_PlayerSpawner`
4. Attach camera boom and input movement bindings in Project Settings



---

## 🧠 Animation + Interaction Blueprint Hooks

### New Blueprints:
- BP_SlotMachine_Interactive → listens for player input (E key) to spin slot animation
- BP_Dealer_EmoteTrigger → plays dealer shuffle, thumbs up, or losing emotes
- BP_PlayerWinEmoteTrigger → player performs winning emote when outcome = win
- BP_AnimationBridge → handles animation dispatch to any skeletal mesh component

### Implementation Instructions:
1. Add `BP_SlotMachine_Interactive` to slot machines, bind OnInteract → PlayTimeline
2. Place `BP_Dealer_EmoteTrigger` near tables, hook to dealer mesh
3. Use `BP_PlayerWinEmoteTrigger` on slots or table game result logic
4. Use `BP_AnimationBridge` to broadcast emote events to mesh AnimBP state machine
5. Use timeline or montage to blend emotes on top of idle/walk



---

## 🆕 Phase 2 Expansion

### VIP Lounge:
- `VIP_Lounge.umap` — new exclusive map zone
- `BP_VIPAccessTrigger` — triggers entry logic based on VIP tier or currency

### Avatar Store:
- `AvatarStoreUI.uasset` — cosmetic UI overlay (hats, suits, emotes)
- `SM_StoreDisplay.fbx` — interactive 3D display kiosk

### Sportsbook UI:
- `SportsbookUI.uasset` — betting terminal interface
- `SM_SportsBettingTerminal.fbx` — static mesh kiosk
- Hooks into `/sportsbook/odds` backend endpoint

## Integration Instructions:
- Mount VIP_Lounge to `CasinoFloor` via level streaming
- Place access triggers at hallway entrances
- Link UI widgets to player HUD layer
- Configure logic: VIP gate, cosmetic transactions, and real-time bet submissions



---

## 🛒 Cosmetic Transaction System

**Backend Logic**: `avatarStore.js`
- Function: `purchaseItem(userId, itemName, price)`
- Deducts from user balance
- Adds item to user inventory
- Returns updated balance

---

## 💸 Sportsbook Betting Sync

**Backend Logic**: `sportsbookBetting.js`
- Function: `placeBet(userId, gameId, amount, teamPicked, odds)`
- Logs live bet
- Hook this into `SportsbookUI` for submission and status display

---

## 🧭 Level Streaming: VIP Lounge

**Blueprint**: `BP_StreamVIPLounge`
- Place at hallway entry/exit points
- Auto-loads `VIP_Lounge.umap` on overlap
- Use visibility/logic for smooth transitions



---

## 👥 Multiplayer Party & Chat System

### Party System:
- `createParty(leaderId)`
- `joinParty(partyId, userId)`
- `leaveParty(partyId, userId)`
- Stores party leader + members

### Chat System:
- `sendMessage(userId, content)`
- `getRecentMessages(limit)`
- React component: `ChatBox.js`

### UI Components:
- `PartyPanel.js` – view and leave party
- `ChatBox.js` – casino-wide chat feed + input

## Integration Notes:
- Display party UI in top-right corner
- Overlay ChatBox in bottom-left or tab toggle
- Hook into WebSocket (future phase) for real-time sync



---

## 🌐 WebSocket Integration (Real-Time Sync)

### Server:
- `websocket.js` – launches WS server on port 8080
- Handles chat message broadcast
- Expandable for real-time party invites and location tracking

### Usage:
1. Run `node websocket.js` in `server/`
2. Connect from client using:
```js
const ws = new WebSocket('ws://localhost:8080');
ws.onmessage = (msg) => console.log('RECEIVED:', msg.data);
ws.send(JSON.stringify({ from: 'user1', content: 'hello' }));
```

3. Integrate WebSocket into `ChatBox.js` and `PartyPanel.js` for live updates



---

## 🔄 Firebase Chat & Party History Sync

### New Service:
- `firebasePartyChatSync.js`
  - `saveChatMessage(userId, content)` → stores messages to Firestore
  - `getRecentChatMessages(limit)` → fetches latest messages
  - `saveParty(partyId, leaderId, members)` → stores party data
  - `getParty(partyId)` → fetches current party structure

### Firestore Structure:
```
/chat/{autoId}
/parties/{partyId}
```

### Notes:
- Requires Firebase Admin SDK
- Use with React UI to persist sessions and display historical context



---

## 🛡️ Admin Dashboard

### Server Tools (adminDashboard.js):
- `getAllChatMessages()` — view last 100 messages
- `deleteChatMessage(messageId)` — remove flagged content
- `listAllParties()` — list all active party sessions
- `removeParty(partyId)` — disband party remotely

### React Component:
- `AdminDashboard.js`
  - View chat logs
  - Delete messages with click
  - List all parties + remove

### Setup Notes:
- Use in restricted route or behind login
- Hook to Firebase Admin SDK or secure backend API
- UI ready for audit tools and moderation flags



---

## 🚩 Reporting System + Admin Logs

### Backend:
- `reportSystem.js`
  - `reportMessage(reporterId, messageId, reason)` — logs report
  - `getReports()` — returns last 50 reports

### Frontend:
- `ChatBoxWithFlag.js` — like ChatBox but includes 🚩 button next to each message
- `AdminReportPanel.js` — lists reports with reasons and reporter info

### Firestore Collections:
```
/reports/{autoId}
```

### Usage:
- Replace ChatBox with ChatBoxWithFlag in UI
- Mount AdminReportPanel in dashboard for report visibility



---

## 🔐 Audit Tracking: User Actions (Secure)

### Module:
- `auditLogger.js`

### Tracked Events:
- login, logout
- purchases
- bets
- wins/losses

### Structure:
Firestore Collection: `/audit_logs/{autoId}`

```
{
  userId: "uid123",
  eventType: "purchase",
  eventData: { item: "Gold Tux", price: 250 },
  timestamp: 1720000000000
}
```

### Access:
- Use `getAuditLogs(limit)` only in **secured admin server routes**
- DO NOT expose this data to the client without role-based access control

### Usage Example:
```js
await logAuditEvent('uid123', 'purchase', { item: 'Gold Tux', price: 250 });
```



---

## 🧾 Admin Audit Log Viewer (UI)

### Component: `AdminAuditLogViewer.js`

- Fetches latest 100 audit logs
- Filters:
  - Event Type (`login`, `purchase`, `bet`, etc.)
  - User ID

### Integration:
- Plug into admin dashboard route
- Use with secure API connected to `getAuditLogs(limit)`
- Protect with auth middleware



---

## 🔒 Secure Audit Logging (Isolated + Encrypted)

### File: `secureAuditLogger.js`

- 🔐 AES-256-CBC encryption
- 🔑 Requires `AUDIT_SECRET_KEY` env variable (64 hex chars)
- 🧊 Separate Firestore collection: `/secure_audit_logs`
- No plain-text access
- Only decryptable server-side with key access

### 🔐 Setup:
1. Generate 32-byte hex key: `openssl rand -hex 32`
2. Store in `.env` as `AUDIT_SECRET_KEY`
3. Use `logSecureAuditEvent(userId, eventType, eventData)` for sensitive events

### Best Practices:
- Never expose this API to clients
- Do not provide UI access to secure logs
- Use a cold storage backup pipeline if needed



---

## 📤 Audit Log Export (Admin Use Only)

### File: `logExporter.js`
Exports `audit_logs` collection to:

- `audit_logs.csv`
- `audit_logs.json`

### Usage:
```js
await exportAuditLogsToCSV(100, './logs.csv');
await exportAuditLogsToJSON(100, './logs.json');
```

### Notes:
- Outputs to server filesystem
- Do not run from client
- Ideal for compliance exports, backup, or investigations



---

## 🧊 Cold Storage / Off-Site Logging (S3 Glacier)

### File: `offsiteLogger.js`

Exports audit logs and backs them up to **Amazon S3 (Glacier)** for long-term cold storage.

### Requirements:
- `AWS_ACCESS_KEY_ID`
- `AWS_SECRET_ACCESS_KEY`
- `AWS_REGION`
- Bucket name (must exist)

### Usage:
```js
await backupAuditLogsToS3('vegasrealms-backup-bucket');
```

### S3 Storage Class:
- Files stored as `StorageClass: 'GLACIER'` (archival)



---

## 🧠 Intelligent Moderation & Anomaly Alerts

### File: `moderationAI.js`

### Features:
- 🔍 **Anomaly Detection** (words like "hack", "exploit", etc.)
- 🧮 **Moderation Score Tracker** (`/mod_scores`)
- 🚨 **Admin Alert System** (`/alerts`)

### Auto-Monitor Workflow:
1. Analyze incoming chat messages
2. Raise alerts on anomalies
3. Increment moderation score for flagged users
4. Log score + alert to Firestore

### Usage:
```js
await moderateMessage('uid123', 'I found a way to hack the slots');
```



---

## ⚖️ Automated Punishment System

### File: `punishmentEngine.js`

### Punishment Thresholds:
- `>= 5` — ⚠️ Warning (UI message)
- `>= 10` — 🔇 Mute (chat disabled for 1 hour)
- `>= 20` — ❄️ Cooldown (bets/party/chat disabled for 1 hour)
- `>= 30` — 🚫 Auto-Ban (account locked)

### Firestore Collection:
- `/punishments/{userId}` — active punishment per user

### Core Functions:
```js
await enforcePunishment('uid123'); // evaluates + applies punishment
await checkPunishment('uid123');  // returns current active punishment (if any)
```

### Notes:
- All punishments are time-based and auto-expire
- Mute/cooldown logic must be respected in UI/backend access



---

## 🧾 Player-Facing Behavior Report Card

### File: `BehaviorReportCard.js`

Displays:
- 🔢 Mod Score
- 🚫 Active punishment type (if any)
- 🔍 Explanation and risk levels (mute, cooldown, ban)

### Usage:
Place inside any authenticated player dashboard.

Props required:
- `userId`
- `fetchModScore(userId)`
- `fetchPunishment(userId)`

### Example Render:
```jsx
<BehaviorReportCard
  userId={'uid123'}
  fetchModScore={yourBackendScoreFunction}
  fetchPunishment={yourBackendPunishmentFetcher}
/>
```



---

## 🔥 Chaos Mode (GTA-Style Mayhem)

### File: `chaosMode.js`

Chaos Mode transforms the environment:
- 🔫 PvP weapons enabled
- 🚓 Cops & gang NPCs roam the map
- 💸 Robbery systems activate (ATMs, stores, casino cages)
- 🚗 Stolen vehicles spawn
- 📈 Law level escalates over time

### API:
```js
await enableChaosMode(); // Global enable
await enableChaosMode('userId'); // Per-player instance

await disableChaosMode();
await isChaosModeActive(); // Check status
```

### Firestore:
- `/chaos_mode_status/global` or `/chaos_mode_status/{userId}`

Use UE5 to flip behavior trees and event spawns based on this flag.



---

## 🤝 Addiction Support Group Rooms

### File: `supportGroups.js`

- Creates support room entries (e.g. "backroom-12")
- Used for in-game recovery meetings
- Can only be accessed via:
  - Jump-to button at start
  - Portal/backdoor in game (behind casino floor)

---

## 🔫 Wanted Level System (Chaos Mode)

### File: `wantedLevel.js`
- Tracks escalating crime severity
- Increases based on theft, PvP, etc.
- Auto-decays over time

```js
await increaseWantedLevel(userId, 2);
await decayWantedLevel(userId);
```

Stored in: `/wanted_levels/{userId}`

---

## 🔐 Secret Chaos Mode Activation

### File: `chaosAccessCode.js`

```js
validateChaosCode('UpDownLeftLeftBaCaB'); // returns true
```

- Must be typed on main menu
- No UI visible — activates Chaos Mode if correct
- Exclusive/private access



---

## 🏆 Chaos Mode Leaderboard

### File: `chaosLeaderboard.js`

Tracks most chaotic players by cumulative score:
```js
await updateChaosScore(userId, 5);
const top10 = await getTopChaosPlayers();
```

Collection: `/chaos_leaderboard`

---

## 🎯 Chaos Bounty System

### File: `bountySystem.js`

Auto-assigns bounty if player becomes notorious:
```js
await assignBounty('uid123', 150); // assigns 15,000 value bounty
await claimBounty('hunter456', 'uid123'); // hunter claims bounty
```

Collection: `/chaos_bounties`

---

## 🎭 UE5 Cop/Gang NPCs (Coming Up)

- Behavior trees:
  - **Patrol > Alert > Engage > Chase > Arrest/Kill**
  - Gang faction logic with escalating hostility
  - UE5 blueprint support & blackboard setup



---

## 🔐 Chaos Mode Real Penalties System

### File: `chaosPenalties.js`

- Real-time jail (1+ hours offline/locked)
- Theft logs & enforcement
- Max steal: 5% of victim’s real balance
- Victims never lose more than the capped percent

---

## ✍️ Required Agreement: `chaosModeContract.md`

**Mandatory before playing Chaos Mode.**

Terms:
- Player agrees to real financial risks
- Player agrees to jail time, fines, and enforcement
- Must digitally "sign" to enter

### Signature Flow:
- Shown before mode loads
- Requires re-authentication (e.g. password entry)
- Refusal = no access to Chaos Mode



---

## ⚖️ Chaos Court System

### File: `chaosCourt.js`

- Opens court cases for chaos crimes
- AI or player judge/lawyer system
- Verdict sets jail time and fines

```js
await openCourtCase('uid123', ['robbery'], 'cop456');
await closeCourtCase('uid123_1689', 'guilty', 3, 250);
```

---

## 🧑‍⚖️ In-Game Job System

### File: `jobApplications.js`

- Players apply for jobs (cop, judge, dealer)
- Admins or HR AI approve/deny
- Used for in-game authority roles

```js
await submitJobApplication('uid123', 'lawyer', 'I passed virtual bar');
await reviewJobApplication('uid123_lawyer', 'approved');
```

---

## 🧠 Lawyer Matchmaking

### File: `lawyerMatchmaker.js`

- Auto-pairs defendant with approved lawyer
- AI fallback if no player available

```js
await getLawyerForCase('uid123');
```

---

## 🎮 UE5 Assets in Progress:
- `copAI_BT.uasset`
- `gangAI_BT.uasset`
- `jailScene.umap`
- `courtRoom.umap`
- `countdownWidget.uasset`



---

## ⚕️ Support Group Meeting System

### File: `supportSchedule.js`
- Schedules recovery meetings
- Allows listing future sessions
```js
await scheduleMeeting('uid123', 'Addiction Recovery', 1720888800000, 60);
await listUpcomingMeetings();
```

---

## 🧑‍💼 Recovery Facilitator Role

### File: `recoveryFacilitatorApproval.js`
- Apply to become a group leader
- Manual or AI approval system
```js
await applyForFacilitator('uid123', 'I have 3 years of sobriety and lead meetings.');
await reviewFacilitator('uid123', 'approved');
```

---

## 🔊 Support Voice Room Registry

### File: `supportRoomRegistry.js`
- Registers voice chat rooms with privacy controls
```js
await registerSupportRoom('room001', 'host123', true);
```

---

📦 All support group systems now wired for front-end integration and UE5 scene logic.



---

## 🛋️ Support Room (UE5 Map)

### File: `supportRoom.umap`

- AA-style recovery circle layout
- Warm tone lighting and calm background sound
- 12-Step program posters integrated
- Live player voice zones (spatial)

---

## 📅 Support Calendar UI

### File: `calendarBookingUI.uasset`

- Book or browse scheduled sessions
- See open groups, timezones, host name
- Integrated with `supportSchedule.js`

---

## 📊 Host Dashboard + Recovery Stats

### File: `hostDashboardWidget.uasset` & `hostDashboard.js`

- Displays meeting logs (participants, shares, duration)
- Facilitator can see top shared sessions
- Tracks number of sessions hosted
```js
await logParticipantStats('session01', 'uid123', 45, true);
await getFacilitatorStats('uid123');
```

---



---

## 🎮 Dual Game Modes: Original vs Chaos Mode

### File: `gameModeManager.js`

- Players can be in one of two game modes:
  - `original` – standard gameplay, no exposure to crime
  - `chaos` – full sandbox mode with criminal freedom

- **Visibility Rules:**
  - Chaos players see everyone
  - Original players only see others in original mode
  - Prevents harassment/griefing from Chaos mode users

- **Chaos Marker:**
  - Players in chaos mode wear a GREEN wristband on avatar

```js
await setPlayerMode('uid123', 'chaos'); // Activates green wristband
await canSeePlayer('viewerId', 'targetId');
```

---



---

## 🎨 Chaos Mode Wristband

- File: `ChaosWristband_MAT.uasset`
- Green band attached to avatars in Chaos Mode
- Dynamic mesh assignment on mode switch

---

## 📝 Chaos Mode Confirmation UI

- File: `ChaosModeConfirmationUI.uasset`
- Pops up contract & risks before activation
- Confirm or cancel before entering chaos

---

## 🕶️ Shadow Wall System

- File: `ShadowWall_Blueprint.uasset`
- Prevents Chaos players from rendering to Original Mode users
- Auto-hides Chaos avatars in mixed lobbies

---

## 🔊 Support Voice + Text Logic

- File: `SupportVoiceZone_BP.uasset`
- Spatial voice zone + text chat in support rooms only
- Mute, report, share-via-text enabled
- Voice logic restricted to support mode by default

---

## 🏅 Recovery Badge System

- File: `recoveryBadgeSystem.js` & `RecoveryBadgeUI.uasset`
- Tiers: Bronze (0–89 days), Silver (90–179), Gold (180+)
- Shows sobriety days on user profile

```js
await assignRecoveryBadge('uid123', 1710028800000);
await getRecoveryStatus('uid123');
```

---


---

## 📡 Live Sports Odds Integration

- File: `oddsAPIConnector.js`
- Placeholder for live odds API (e.g., TheOddsAPI, Bet365)
- Used to feed real betting lines into `sportsBettingEngine.js`

---

## 🎖️ Achievement Badge Materials

- Files:
  - `AchievementBadge_Bronze.uasset`
  - `AchievementBadge_Silver.uasset`
  - `AchievementBadge_Gold.uasset`
- Attached to avatar chest or sleeve
- Updated dynamically by `achievementTracker.js`

---

## 🎬 Teaser Trailer Visuals

- Files:
  - `OriginalMode_Teaser_Storyboard_01.png` → Clean casino floor
  - `...02.png` → Players enjoying calm play
  - `...03.png` → Glass breaking chaos glimpse
  - `...04.png` → Rewards + logo overlay

---



---

## 🛠️ FINAL UPGRADES

### 📡 Sports Betting API Key

- File: `oddsAPI.config.json`
- Provider: TheOddsAPI
- Plug your real API key for full live odds support

---

### 🎬 Teaser Animation Script

- File: `OriginalMode_Teaser_Storyboard_Animation.json`
- Includes pan, shake, fade, and voiceover timing
- Plug into render engine to auto-generate teaser

---

### 🎖️ Avatar Badge Renderer

- File: `BadgeRenderer_BP.uasset`
- UE5 logic: renders achievement badge to upper torso mesh
- Dynamic badge swapping based on `achievementTracker.js`

---


---

## 🖥️ Betting Dashboard UI

- File: `BettingDashboard_UI.uasset`
- Displays:
  - Live odds
  - Your bets
  - Game clock and payout potential

---

## 🎬 Teaser Render Queue

- File: `TeaserRenderQueue.json`
- Preload for cutscene-style render of Original Mode trailer
- Converts storyboard into full `.mp4` with effects

---

## 🏆 Player Leaderboard System

- File: `playerLeaderboard.js`
- Builds top achievement earners based on points
- Saves to `leaderboard` collection for public or lobby view

```js
await generateLeaderboard(10);
```

---


---

## 🎥 Playable Teaser Cutscene

- File: `PlayableTeaser_BP.uasset`
- Runs cinematic intro on game launch (can be skipped)
- Syncs with rendered teaser .mp4 for full immersion

---

## 🏛️ Casino Wall Leaderboard

- File: `LobbyLeaderboardDisplay.uasset`
- Displays top 10 Original Mode players in lobby
- Real-time updates via Firestore

---

## 📱 Mobile Betting UI Sync

- File: `BettingDashboardMobile.js`
- Auto-refreshes odds + bet status every 15 seconds
- Mobile-optimized with responsive design

---


---

## 🔊 Sound & Voice System

- `SoundEngineManager_BP.uasset`: Routes sound by game mode
- `Ambient_Casino.uasset`: Background loop for calm atmosphere
- `ChaosModeAlerts.uasset`: Alarms, panic, action SFX
- `DealerVoiceSet.uasset`: Blackjack dealer voiceovers

## 🎙️ Voiceover Scripts

- `Voiceover_Script_ChaosContract.txt`: Narration lines before entering Chaos Mode

---

## 🤖 NPC Behavior Blueprints

- `NPCIdleBehavior_BP.uasset`: Sits, drinks, reacts, panics (Chaos)
- `SupportHostNPC_BP.uasset`: Paces, greets, shares supportive lines

---


---

## 🧠 Lip Sync + Emotes System

- File: `LipSync_Emotes_BP.uasset`
- Syncs VO lines with facial morph targets and avatar emotes

## 🧪 In-World Testing Scripts

- `InWorld_TestScenario01.js`: Simulates full player flow, from login to trial
- Useful for automated demo playthroughs or QA

## 🎙️ Voiceover Audio Pack System

- `VoicePackLoader_BP.uasset`: Maps triggers to VO audio files
- `VoicePackIndex.json`: Index of phrases and filenames

---


---

## 🌍 UE5 Runtime Launch

- File: `TestRealmLauncher.uasset`
- Bootable instance to launch full VegasRealms sandbox in Unreal Engine
- Loads all modes with proper player separation

## 🧪 Private Alpha Build

- File: `AlphaBuild_Config.json`
- Invite-only access across PC, Mac, Mobile
- Lockable chaos features, dev logging enabled

## 🎤 Voice Casting Configuration

- Files:
  - `VoiceCastingSheet.csv`: Lists roles and voice talent type
  - `SynthVoiceConfig.json`: Maps roles to ElevenLabs AI voices

---


---

## 🎤 Voiceover Audio Generated

- Chaos Narration: `ChaosContractVO_01.wav`
- Dealer: `Dealer_Blackjack.wav`
- Judge: `Judge_Sentence.wav`
- Support Host: `SupportHost_Welcome.wav`

---

## 🌍 Test Realm Runtime Config

- File: `VegasRealms_TestRealm.uproject`
- Fully playable: Original, Chaos, Support worlds
- Use UE5.3 or higher to launch

---

## 🧪 Alpha Testing Suite

- `FeedbackPopup_UI.uasset`: Feedback UI
- `TestSessionLogger.js`: Real-time tester logs
- `SendFeedback.js`: Auto-email tester reports to dev inbox

---
