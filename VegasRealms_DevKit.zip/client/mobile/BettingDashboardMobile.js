function syncMobileOdds() {
    fetch('/api/live-odds')
        .then(res => res.json())
        .then(data => {
            updateOddsUI(data);
        });

    setTimeout(syncMobileOdds, 15000); // refresh every 15s
}
