import React from 'react';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase-config';

function Dashboard() {
    return (
        <div>
            <h2>Dashboard</h2>
            <p>Welcome to Vegas Realms Online</p>
            <button onClick={() => signOut(auth)}>Logout</button>
        </div>
    );
}

export default Dashboard;
