import React, { useEffect, useState } from 'react';

function AdminDashboard({ fetchMessages, fetchParties, deleteMessage, deleteParty }) {
    const [messages, setMessages] = useState([]);
    const [parties, setParties] = useState([]);

    useEffect(() => {
        fetchMessages().then(setMessages);
        fetchParties().then(setParties);
    }, []);

    return (
        <div>
            <h2>Admin Dashboard</h2>

            <h3>Chat Moderation</h3>
            <ul>
                {messages.map(msg => (
                    <li key={msg.id}>
                        <strong>{msg.from}:</strong> {msg.content}
                        <button onClick={() => deleteMessage(msg.id)}>🗑 Delete</button>
                    </li>
                ))}
            </ul>

            <h3>Active Parties</h3>
            <ul>
                {parties.map(p => (
                    <li key={p.id}>
                        <strong>{p.leaderId}</strong> — {p.members.join(', ')}
                        <button onClick={() => deleteParty(p.id)}>🗑 Remove</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default AdminDashboard;
