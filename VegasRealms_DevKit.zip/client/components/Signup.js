import React, { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase-config';

function Signup() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const signupUser = async () => {
        try {
            await createUserWithEmailAndPassword(auth, email, password);
            alert('Signup successful!');
        } catch (error) {
            alert(error.message);
        }
    };

    return (
        <div>
            <h2>Signup</h2>
            <input placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
            <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
            <button onClick={signupUser}>Signup</button>
        </div>
    );
}

export default Signup;
