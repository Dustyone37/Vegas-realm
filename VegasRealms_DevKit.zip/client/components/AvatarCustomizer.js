import React, { useState } from 'react';

function AvatarCustomizer({ onSave }) {
    const [avatar, setAvatar] = useState({
        hat: '',
        glasses: '',
        outfit: '',
        accessory: ''
    });

    const handleChange = (e) => {
        setAvatar({ ...avatar, [e.target.name]: e.target.value });
    };

    const saveAvatar = () => {
        onSave(avatar);
        alert('Avatar customization saved!');
    };

    return (
        <div>
            <h2>Customize Your Avatar</h2>
            <input name="hat" placeholder="Hat" onChange={handleChange} />
            <input name="glasses" placeholder="Glasses" onChange={handleChange} />
            <input name="outfit" placeholder="Outfit" onChange={handleChange} />
            <input name="accessory" placeholder="Accessory" onChange={handleChange} />
            <button onClick={saveAvatar}>Save Avatar</button>
        </div>
    );
}

export default AvatarCustomizer;
