import React, { useState } from 'react';

function PartyPanel({ party, onLeave }) {
    return (
        <div>
            <h3>Party Members</h3>
            <ul>
                {party.members.map((m, idx) => <li key={idx}>{m}</li>)}
            </ul>
            <button onClick={onLeave}>Leave Party</button>
        </div>
    );
}

export default PartyPanel;
