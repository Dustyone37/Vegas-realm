import React, { useEffect, useState } from 'react';

function BehaviorReportCard({ userId, fetchModScore, fetchPunishment }) {
    const [score, setScore] = useState(null);
    const [punishment, setPunishment] = useState(null);

    useEffect(() => {
        async function fetchData() {
            const userScore = await fetchModScore(userId);
            const currentPunishment = await fetchPunishment(userId);
            setScore(userScore);
            setPunishment(currentPunishment);
        }
        fetchData();
    }, [userId]);

    return (
        <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', backgroundColor: '#f7f7f7' }}>
            <h3>Your Behavior Score</h3>
            {score !== null ? (
                <>
                    <p><strong>Current Mod Score:</strong> {score}</p>
                    <p style={{ color: score >= 30 ? 'red' : score >= 20 ? 'orange' : 'black' }}>
                        {score >= 30 ? "⚠️ You are banned due to high infraction level." :
                         score >= 20 ? "You are currently in cooldown status." :
                         score >= 10 ? "You are muted for chat violations." :
                         score >= 5  ? "You’ve received a system warning. Stay cool!" :
                         "All good. Keep playing responsibly!"}
                    </p>
                    {punishment && (
                        <>
                            <p><strong>Active Punishment:</strong> {punishment.type}</p>
                            <p><em>Will expire automatically if no further violations occur.</em></p>
                        </>
                    )}
                </>
            ) : (
                <p>Loading behavior data...</p>
            )}
        </div>
    );
}

export default BehaviorReportCard;
