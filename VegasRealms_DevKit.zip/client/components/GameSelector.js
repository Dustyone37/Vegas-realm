import React from 'react';

function GameSelector({ setGame }) {
    return (
        <div>
            <h2>Choose Your Game</h2>
            <button onClick={() => setGame('slot')}>🎰 Slot Machine</button>
            <button onClick={() => setGame('poker')}>🃏 Poker</button>
            <button onClick={() => setGame('blackjack')}>♠ Blackjack</button>
            <button onClick={() => setGame('sportsbook')}>📈 Sportsbook</button>
        </div>
    );
}

export default GameSelector;
