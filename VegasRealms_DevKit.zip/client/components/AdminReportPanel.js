import React, { useEffect, useState } from 'react';

function AdminReportPanel({ fetchReports }) {
    const [reports, setReports] = useState([]);

    useEffect(() => {
        fetchReports().then(setReports);
    }, []);

    return (
        <div>
            <h3>Reported Messages</h3>
            <ul>
                {reports.map((report, idx) => (
                    <li key={idx}>
                        <strong>{report.reporterId}</strong> reported <strong>{report.messageId}</strong> — {report.reason}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default AdminReportPanel;
