import React, { useEffect, useState } from 'react';

function AdminAuditLogViewer({ fetchLogs }) {
    const [logs, setLogs] = useState([]);
    const [filter, setFilter] = useState('');
    const [userIdFilter, setUserIdFilter] = useState('');

    useEffect(() => {
        fetchLogs().then(setLogs);
    }, []);

    const filteredLogs = logs.filter(log =>
        (filter === '' || log.eventType.toLowerCase().includes(filter.toLowerCase())) &&
        (userIdFilter === '' || log.userId === userIdFilter)
    );

    return (
        <div>
            <h2>Audit Log Viewer</h2>
            <label>
                Filter by Event Type:
                <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="e.g., login, purchase" />
            </label>
            <label>
                Filter by User ID:
                <input value={userIdFilter} onChange={(e) => setUserIdFilter(e.target.value)} placeholder="User ID" />
            </label>
            <ul style={{ maxHeight: '300px', overflowY: 'scroll' }}>
                {filteredLogs.map((log, idx) => (
                    <li key={idx}>
                        <strong>{log.userId}</strong> — {log.eventType}
                        <br />
                        <small>{JSON.stringify(log.eventData)}</small>
                        <br />
                        <em>{new Date(log.timestamp).toLocaleString()}</em>
                        <hr />
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default AdminAuditLogViewer;
