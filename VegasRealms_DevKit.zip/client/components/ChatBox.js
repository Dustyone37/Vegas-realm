import React, { useState, useEffect } from 'react';

function ChatBox({ sendMessage, messages }) {
    const [input, setInput] = useState('');

    const handleSend = () => {
        sendMessage(input);
        setInput('');
    };

    return (
        <div>
            <h3>Casino Chat</h3>
            <div style={{ height: '150px', overflowY: 'scroll', background: '#222', color: '#fff', padding: '8px' }}>
                {messages.map((msg, idx) => (
                    <div key={idx}><strong>{msg.from}:</strong> {msg.content}</div>
                ))}
            </div>
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Say something..." />
            <button onClick={handleSend}>Send</button>
        </div>
    );
}

export default ChatBox;
