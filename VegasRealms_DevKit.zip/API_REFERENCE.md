# API Reference

## Auth
- `/signup`
- `/login`

## Games
- `/slot/start`
- `/poker/play`

## Transactions
- `/wallet/deposit`
- `/wallet/withdraw`
