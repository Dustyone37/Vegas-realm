## Vegas Realms Seasonal Event Ideas
- 🎉 New Year's Casino Bash — Fireworks, rare drops, countdown event
- ⚖️ Support Week — Recovery tokens, extra XP for sobriety milestones
- 💰 Chaos Cup — 7-day leaderboard with real prizes and top notoriety rank
