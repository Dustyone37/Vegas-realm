## Planned Future Zones
- Rooftop Poker Lounge (invite-only, real stakes)
- Underground Fight Club (avatar-only wagers)
- VR Skin Showroom (customization emporium)
