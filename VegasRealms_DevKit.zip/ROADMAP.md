# Development Roadmap

## Phase 1: MVP
- Slot Machine Engine
- Firebase Auth & Firestore
- Node.js Backend APIs

## Phase 2: Alpha
- Poker & Blackjack Logic
- Sportsbook Engine
- Multiplayer Lobby

## Phase 3: Beta
- UE5 Frontend Integration
- VIP Memberships
- NFT Skin System