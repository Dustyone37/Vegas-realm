# Vegas Realms Online

This is the starter dev kit for Vegas Realms Online — a real-money casino MMO.
