const express = require('express');
const router = express.Router();
const admin = require('firebase-admin');

router.post('/signup', async (req, res) => {
    const { email, password, displayName } = req.body;
    try {
        const userRecord = await admin.auth().createUser({ email, password, displayName });
        res.status(201).send({ uid: userRecord.uid });
    } catch (error) {
        res.status(400).send({ error: error.message });
    }
});

router.post('/login', async (req, res) => {
    // Placeholder: Firebase client-side SDK handles login; return token if needed
    res.status(200).send({ message: 'Login handled via Firebase client SDK' });
});

module.exports = router;
