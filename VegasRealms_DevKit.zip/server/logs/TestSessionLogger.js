const fs = require('fs');
module.exports = function logTestEvent(userId, action) {
  const line = `${new Date().toISOString()} | ${userId} | ${action}\n`;
  fs.appendFileSync('test_session_log.txt', line);
}
