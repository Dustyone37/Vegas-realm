const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const BETS = 'sports_bets';
const ODDS = 'live_sports_odds';

/**
 * Place a bet on a live game
 */
async function placeBet(userId, matchId, team, amount) {
    const oddsSnap = await db.collection(ODDS).doc(matchId).get();
    if (!oddsSnap.exists) throw new Error("Match not found");

    const odds = oddsSnap.data();
    const payout = amount * odds[team];

    await db.collection(BETS).add({
        userId,
        matchId,
        team,
        amount,
        payoutPotential: payout,
        placedAt: Date.now(),
        resolved: false
    });

    return { success: true, payout };
}
