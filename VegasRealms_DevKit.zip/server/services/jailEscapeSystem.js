const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const JAIL = 'chaos_jail';

/**
 * Attempt a jail escape — high risk, low odds
 */
async function attemptEscape(userId) {
    const jailRef = db.collection(JAIL).doc(userId);
    const jailSnap = await jailRef.get();

    if (!jailSnap.exists) return { success: false, reason: 'Not in jail' };

    const odds = Math.random();

    if (odds > 0.9) {
        await jailRef.delete();
        return { success: true, escaped: true };
    } else {
        await jailRef.update({ escapeAttemptedAt: Date.now() });
        return { success: false, caught: true };
    }
}
