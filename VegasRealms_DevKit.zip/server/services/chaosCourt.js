const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const CHAOS_CASES = 'chaos_court_cases';

/**
 * Create a new court case
 */
async function openCourtCase(defendantId, charges, arrestingOfficerId) {
    const caseId = defendantId + '_' + Date.now();
    await db.collection(CHAOS_CASES).doc(caseId).set({
        caseId,
        defendantId,
        arrestingOfficerId,
        charges,
        openedAt: Date.now(),
        status: 'open'
    });
    return { success: true, caseId };
}

/**
 * Close court case (verdict)
 */
async function closeCourtCase(caseId, verdict, sentenceHours, fineAmount) {
    const ref = db.collection(CHAOS_CASES).doc(caseId);
    await ref.update({
        status: 'closed',
        verdict,
        sentenceHours,
        fineAmount,
        closedAt: Date.now()
    });
    return { success: true };
}
