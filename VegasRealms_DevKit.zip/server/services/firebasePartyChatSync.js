const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();

async function saveChatMessage(userId, content) {
    const doc = {
        from: userId,
        content,
        timestamp: Date.now()
    };
    await db.collection('chat').add(doc);
    return doc;
}

async function getRecentChatMessages(limit = 50) {
    const snapshot = await db.collection('chat').orderBy('timestamp', 'desc').limit(limit).get();
    return snapshot.docs.map(doc => doc.data()).reverse();
}

async function saveParty(partyId, leaderId, members) {
    const partyDoc = { leaderId, members, updated: Date.now() };
    await db.collection('parties').doc(partyId).set(partyDoc);
    return partyDoc;
}

async function getParty(partyId) {
    const doc = await db.collection('parties').doc(partyId).get();
    return doc.exists ? doc.data() : null;
}

module.exports = {
    saveChatMessage,
    getRecentChatMessages,
    saveParty,
    getParty
};
