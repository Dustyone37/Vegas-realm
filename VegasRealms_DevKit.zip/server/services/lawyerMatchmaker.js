const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const LAWYERS = 'job_applications';

/**
 * Find available lawyer or assign AI fallback
 */
async function getLawyerForCase(defendantId) {
    const snapshot = await db.collection(LAWYERS)
        .where('role', '==', 'lawyer')
        .where('status', '==', 'approved')
        .limit(1)
        .get();

    if (snapshot.empty) {
        return { assigned: 'AI-Bot-Lawyer', fallback: true };
    }

    const lawyer = snapshot.docs[0].data();
    return { assigned: lawyer.userId, fallback: false };
}
