const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const JAIL = 'chaos_jail';
const BALANCES = 'user_balances';

/**
 * Attempt bail payment for jailed user
 */
async function payBail(userId, bailAmount) {
    const balanceRef = db.collection(BALANCES).doc(userId);
    const jailRef = db.collection(JAIL).doc(userId);

    const [balSnap, jailSnap] = await Promise.all([balanceRef.get(), jailRef.get()]);

    if (!balSnap.exists || !jailSnap.exists) return { success: false, reason: 'Data missing' };
    if (balSnap.data().realMoney < bailAmount) return { success: false, reason: 'Insufficient funds' };

    // Pay and release
    await balanceRef.update({ realMoney: balSnap.data().realMoney - bailAmount });
    await jailRef.delete();

    return { success: true, released: true };
}
