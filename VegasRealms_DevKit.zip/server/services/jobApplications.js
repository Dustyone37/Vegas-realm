const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const JOB_APPLICATIONS = 'job_applications';

/**
 * Submit a player job application
 */
async function submitJobApplication(userId, role, bio) {
    await db.collection(JOB_APPLICATIONS).doc(userId + "_" + role).set({
        userId,
        role,
        bio,
        submittedAt: Date.now(),
        status: 'pending'
    });
    return { success: true };
}

/**
 * Review and update job application (admin use only)
 */
async function reviewJobApplication(appId, newStatus) {
    const ref = db.collection(JOB_APPLICATIONS).doc(appId);
    await ref.update({ status: newStatus, reviewedAt: Date.now() });
    return { success: true };
}
