const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();

async function getAllChatMessages(limit = 100) {
    const snapshot = await db.collection('chat').orderBy('timestamp', 'desc').limit(limit).get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

async function deleteChatMessage(messageId) {
    await db.collection('chat').doc(messageId).delete();
    return { success: true };
}

async function listAllParties() {
    const snapshot = await db.collection('parties').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}

async function removeParty(partyId) {
    await db.collection('parties').doc(partyId).delete();
    return { success: true };
}

module.exports = {
    getAllChatMessages,
    deleteChatMessage,
    listAllParties,
    removeParty
};
