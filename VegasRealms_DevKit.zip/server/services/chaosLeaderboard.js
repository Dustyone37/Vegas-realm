const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const CHAOS_LEADERBOARD = 'chaos_leaderboard';

/**
 * Update leaderboard score for a chaos player
 */
async function updateChaosScore(userId, delta) {
    const ref = db.collection(CHAOS_LEADERBOARD).doc(userId);
    const doc = await ref.get();
    const currentScore = doc.exists ? doc.data().score : 0;
    const newScore = currentScore + delta;

    await ref.set({
        score: newScore,
        userId,
        updatedAt: Date.now()
    });
    return newScore;
}

/**
 * Get top chaos leaderboard
 */
async function getTopChaosPlayers(limit = 10) {
    const snapshot = await db.collection(CHAOS_LEADERBOARD)
        .orderBy('score', 'desc')
        .limit(limit)
        .get();
    return snapshot.docs.map(doc => doc.data());
}
