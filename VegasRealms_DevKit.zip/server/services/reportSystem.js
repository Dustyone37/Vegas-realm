const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

async function reportMessage(reporterId, messageId, reason) {
    const report = {
        reporterId,
        messageId,
        reason,
        timestamp: Date.now()
    };
    await db.collection('reports').add(report);
    return { success: true, report };
}

async function getReports(limit = 50) {
    const snapshot = await db.collection('reports').orderBy('timestamp', 'desc').limit(limit).get();
    return snapshot.docs.map(doc => doc.data());
}

module.exports = {
    reportMessage,
    getReports
};
