const fs = require('fs');
const path = require('path');
const AWS = require('aws-sdk');
const { exportAuditLogsToJSON } = require('./logExporter');

AWS.config.update({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
});

const s3 = new AWS.S3();

/**
 * Exports audit logs and uploads to S3 cold storage
 */
async function backupAuditLogsToS3(bucketName, filename = 'audit_logs.json') {
    const localPath = path.join('/tmp', filename);
    await exportAuditLogsToJSON(500, localPath);

    const fileContent = fs.readFileSync(localPath);

    const params = {
        Bucket: bucketName,
        Key: `backups/${filename}`,
        Body: fileContent,
        StorageClass: 'GLACIER'
    };

    const result = await s3.upload(params).promise();
    return { success: true, url: result.Location };
}

module.exports = { backupAuditLogsToS3 };
