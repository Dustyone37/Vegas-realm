const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const JAIL_COLLECTION = 'chaos_jail';
const USER_BALANCES = 'user_balances';
const TRANSACTIONS = 'chaos_thefts';

/**
 * Jail user in real-time (real-world time) and log offense
 */
async function jailUser(userId, durationHours, reason) {
    await db.collection(JAIL_COLLECTION).doc(userId).set({
        jailedAt: Date.now(),
        durationHours,
        releaseAt: Date.now() + durationHours * 3600000,
        reason
    });
    return { success: true, jailedUntil: Date.now() + durationHours * 3600000 };
}

/**
 * Steal capped percentage of another user's real balance
 */
async function stealFunds(fromUserId, toUserId, percent = 0.05) {
    const victimRef = db.collection(USER_BALANCES).doc(toUserId);
    const attackerRef = db.collection(USER_BALANCES).doc(fromUserId);

    const victimDoc = await victimRef.get();
    const attackerDoc = await attackerRef.get();

    if (!victimDoc.exists || !attackerDoc.exists) return { success: false, reason: "User not found" };

    const victimBalance = victimDoc.data().realMoney;
    const maxStealAmount = Math.floor(victimBalance * percent);

    if (maxStealAmount <= 0) return { success: false, reason: "No money to steal" };

    // Deduct from victim and add to thief
    await victimRef.update({ realMoney: victimBalance - maxStealAmount });
    await attackerRef.update({ realMoney: attackerDoc.data().realMoney + maxStealAmount });

    // Log transaction
    await db.collection(TRANSACTIONS).add({
        from: toUserId,
        to: fromUserId,
        amount: maxStealAmount,
        time: Date.now()
    });

    return { success: true, amount: maxStealAmount };
}
