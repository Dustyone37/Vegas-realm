const admin = require('firebase-admin');
const crypto = require('crypto');

admin.initializeApp();
const secureDb = admin.firestore();
const SECURE_COLLECTION = 'secure_audit_logs';

/**
 * Encrypt data before writing it to Firestore
 */
function encryptAuditData(data, key = process.env.AUDIT_SECRET_KEY) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key, 'hex'), iv);
    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return {
        iv: iv.toString('hex'),
        encryptedData: encrypted
    };
}

/**
 * Logs a secure and encrypted audit event to a separate collection
 */
async function logSecureAuditEvent(userId, eventType, eventData = {}) {
    const payload = {
        userId,
        eventType,
        eventData,
        timestamp: Date.now()
    };
    const encrypted = encryptAuditData(payload);
    await secureDb.collection(SECURE_COLLECTION).add(encrypted);
    return { success: true };
}

module.exports = { logSecureAuditEvent };
