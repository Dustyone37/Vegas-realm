const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const CHAOS_COLLECTION = 'chaos_mode_status';

/**
 * Enable Chaos Mode for the game or a user instance
 */
async function enableChaosMode(userId = null) {
    const modeRef = userId
        ? db.collection(CHAOS_COLLECTION).doc(userId)
        : db.collection(CHAOS_COLLECTION).doc('global');

    await modeRef.set({
        enabled: true,
        triggeredAt: Date.now()
    });

    return { success: true, chaos: true, scope: userId ? 'user' : 'global' };
}

/**
 * Disable Chaos Mode
 */
async function disableChaosMode(userId = null) {
    const modeRef = userId
        ? db.collection(CHAOS_COLLECTION).doc(userId)
        : db.collection(CHAOS_COLLECTION).doc('global');

    await modeRef.set({
        enabled: false,
        triggeredAt: Date.now()
    });

    return { success: true, chaos: false };
}

/**
 * Check if chaos mode is active
 */
async function isChaosModeActive(userId = null) {
    const modeRef = userId
        ? db.collection(CHAOS_COLLECTION).doc(userId)
        : db.collection(CHAOS_COLLECTION).doc('global');

    const doc = await modeRef.get();
    return doc.exists && doc.data().enabled;
}

module.exports = {
    enableChaosMode,
    disableChaosMode,
    isChaosModeActive
};
