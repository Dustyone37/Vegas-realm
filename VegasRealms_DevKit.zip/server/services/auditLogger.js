const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const AUDIT_COLLECTION = 'audit_logs';

/**
 * Logs a secure audit event.
 * @param {string} userId - The ID of the user performing the action
 * @param {string} eventType - The type of event (e.g., login, purchase, bet)
 * @param {object} eventData - Additional context/data
 */
async function logAuditEvent(userId, eventType, eventData = {}) {
    const auditRecord = {
        userId,
        eventType,
        eventData,
        timestamp: Date.now()
    };
    await db.collection(AUDIT_COLLECTION).add(auditRecord);
    return { success: true };
}

/**
 * Secure fetch (admin only) of audit logs - RESTRICT THIS VIA BACKEND AUTH CHECK.
 */
async function getAuditLogs(limit = 100) {
    const snapshot = await db.collection(AUDIT_COLLECTION)
        .orderBy('timestamp', 'desc')
        .limit(limit)
        .get();
    return snapshot.docs.map(doc => doc.data());
}

module.exports = { logAuditEvent, getAuditLogs };
