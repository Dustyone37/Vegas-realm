const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const SUPPORT_LOGS = 'support_logs';

/**
 * Log participant stats for recovery meetings
 */
async function logParticipantStats(sessionId, userId, durationMin, shared = false) {
    await db.collection(SUPPORT_LOGS).add({
        sessionId,
        userId,
        durationMin,
        shared,
        timestamp: Date.now()
    });
    return { success: true };
}

/**
 * Fetch recovery stats by host or facilitator
 */
async function getFacilitatorStats(hostId) {
    const snapshot = await db.collection(SUPPORT_LOGS)
        .where('userId', '==', hostId)
        .orderBy('timestamp', 'desc')
        .limit(20)
        .get();
    return snapshot.docs.map(doc => doc.data());
}
