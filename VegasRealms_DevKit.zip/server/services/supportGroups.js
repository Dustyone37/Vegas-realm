const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const SUPPORT_ROOM_COLLECTION = 'support_group_sessions';

/**
 * Schedule or join a support group session
 */
async function joinSupportGroup(userId) {
    const sessionRef = db.collection(SUPPORT_ROOM_COLLECTION).doc(userId);
    await sessionRef.set({
        joinedAt: Date.now(),
        userId,
        type: 'gambling_support'
    });
    return { success: true, room: 'backroom-12' };
}

/**
 * Check if user is in a support group
 */
async function isInSupportGroup(userId) {
    const doc = await db.collection(SUPPORT_ROOM_COLLECTION).doc(userId).get();
    return doc.exists;
}

module.exports = {
    joinSupportGroup,
    isInSupportGroup
};
