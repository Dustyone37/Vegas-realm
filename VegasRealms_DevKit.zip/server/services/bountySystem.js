const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const CHAOS_BOUNTY = 'chaos_bounties';

/**
 * Assign bounty based on chaos score threshold
 */
async function assignBounty(userId, score) {
    if (score < 50) return null;
    const bounty = {
        userId,
        value: Math.floor(score * 100),
        createdAt: Date.now(),
        claimed: false
    };
    await db.collection(CHAOS_BOUNTY).doc(userId).set(bounty);
    return bounty;
}

/**
 * Claim bounty
 */
async function claimBounty(hunterId, targetId) {
    const ref = db.collection(CHAOS_BOUNTY).doc(targetId);
    const doc = await ref.get();
    if (!doc.exists || doc.data().claimed) return { success: false };

    await ref.update({
        claimed: true,
        claimedBy: hunterId,
        claimedAt: Date.now()
    });

    return { success: true, bounty: doc.data().value };
}
