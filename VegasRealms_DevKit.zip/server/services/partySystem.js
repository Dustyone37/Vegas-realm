const parties = {};

function createParty(leaderId) {
    const partyId = 'party_' + Date.now();
    parties[partyId] = { leader: leaderId, members: [leaderId] };
    return { partyId, members: parties[partyId].members };
}

function joinParty(partyId, userId) {
    if (!parties[partyId]) return { success: false, message: 'Party not found' };
    if (parties[partyId].members.includes(userId)) return { success: false, message: 'Already in party' };
    parties[partyId].members.push(userId);
    return { success: true, members: parties[partyId].members };
}

function leaveParty(partyId, userId) {
    if (!parties[partyId]) return { success: false, message: 'Party not found' };
    parties[partyId].members = parties[partyId].members.filter(id => id !== userId);
    return { success: true, members: parties[partyId].members };
}

module.exports = { createParty, joinParty, leaveParty };
