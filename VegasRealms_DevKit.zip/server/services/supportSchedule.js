const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const SCHEDULE = 'support_group_schedule';

/**
 * Create or update a support group meeting
 */
async function scheduleMeeting(hostId, topic, startTime, durationMin) {
    const sessionId = hostId + '_' + startTime;
    await db.collection(SCHEDULE).doc(sessionId).set({
        sessionId,
        hostId,
        topic,
        startTime,
        durationMin,
        createdAt: Date.now(),
        attendees: [],
        type: 'support_group'
    });
    return { success: true, sessionId };
}

/**
 * List upcoming support group meetings
 */
async function listUpcomingMeetings() {
    const now = Date.now();
    const snapshot = await db.collection(SCHEDULE)
        .where('startTime', '>', now)
        .orderBy('startTime')
        .limit(10)
        .get();
    return snapshot.docs.map(doc => doc.data());
}
