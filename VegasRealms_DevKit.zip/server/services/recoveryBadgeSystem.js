const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const BADGES = 'recovery_badges';

/**
 * Log sobriety start and assign badge tier
 */
async function assignRecoveryBadge(userId, startTimestamp) {
    const now = Date.now();
    const days = Math.floor((now - startTimestamp) / (1000 * 60 * 60 * 24));
    let tier = 'bronze';

    if (days >= 180) tier = 'gold';
    else if (days >= 90) tier = 'silver';

    await db.collection(BADGES).doc(userId).set({
        userId,
        startTimestamp,
        days,
        tier,
        lastUpdated: now
    });

    return { success: true, tier };
}

/**
 * Get user badge and sobriety timer
 */
async function getRecoveryStatus(userId) {
    const badgeDoc = await db.collection(BADGES).doc(userId).get();
    return badgeDoc.exists ? badgeDoc.data() : null;
}
