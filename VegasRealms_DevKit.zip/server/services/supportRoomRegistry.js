const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const ROOMS = 'support_voice_rooms';

/**
 * Register a new support room with settings
 */
async function registerSupportRoom(roomId, hostId, private = true) {
    await db.collection(ROOMS).doc(roomId).set({
        roomId,
        hostId,
        private,
        createdAt: Date.now(),
        active: true
    });
    return { success: true };
}
