const userInventory = {};

function purchaseItem(userId, itemName, price, currencyType = 'chips') {
    if (!userInventory[userId]) userInventory[userId] = { balance: 1000, items: [] };

    if (userInventory[userId].balance < price) {
        return { success: false, message: 'Insufficient balance' };
    }

    userInventory[userId].balance -= price;
    userInventory[userId].items.push(itemName);

    return { success: true, newBalance: userInventory[userId].balance };
}

module.exports = { purchaseItem };
