const CHAOS_SECRET_CODE = 'UPDOWNLEFTLEFTBACAB'; // Example

/**
 * Validate code entry from menu to activate Chaos Mode
 */
function validateChaosCode(codeInput) {
    return codeInput.toUpperCase() === CHAOS_SECRET_CODE;
}

module.exports = { validateChaosCode };
