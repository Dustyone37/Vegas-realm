const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

const PUNISHMENTS = {
    MUTE: 'mute',
    COOLDOWN: 'cooldown',
    BAN: 'ban'
};

async function getModScore(userId) {
    const doc = await db.collection('mod_scores').doc(userId).get();
    return doc.exists ? doc.data().score : 0;
}

async function applyPunishment(userId, type, duration = null) {
    const ref = db.collection('punishments').doc(userId);
    const punishment = {
        type,
        duration,
        appliedAt: Date.now()
    };
    await ref.set(punishment);
    return { success: true, type, duration };
}

async function enforcePunishment(userId) {
    const score = await getModScore(userId);
    if (score >= 30) {
        return applyPunishment(userId, PUNISHMENTS.BAN);
    } else if (score >= 20) {
        return applyPunishment(userId, PUNISHMENTS.COOLDOWN, 3600); // 1 hour
    } else if (score >= 10) {
        return applyPunishment(userId, PUNISHMENTS.MUTE, 3600); // 1 hour
    } else if (score >= 5) {
        return { warning: true };
    }
    return { ok: true };
}

async function checkPunishment(userId) {
    const doc = await db.collection('punishments').doc(userId).get();
    if (!doc.exists) return null;
    const data = doc.data();
    const now = Date.now();
    if (data.duration && (now - data.appliedAt > data.duration * 1000)) {
        await db.collection('punishments').doc(userId).delete(); // punishment expired
        return null;
    }
    return data;
}

module.exports = {
    enforcePunishment,
    checkPunishment,
    applyPunishment,
    getModScore
};
