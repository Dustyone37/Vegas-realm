const activeBets = [];

function placeBet(userId, gameId, amount, teamPicked, odds) {
    const betId = 'bet_' + Date.now();
    activeBets.push({ betId, userId, gameId, amount, teamPicked, odds, timestamp: Date.now() });
    return { betId, status: 'pending', amount, teamPicked, odds };
}

module.exports = { placeBet };
