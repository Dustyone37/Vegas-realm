const messages = [];

function sendMessage(fromUserId, content) {
    const message = {
        id: 'msg_' + Date.now(),
        from: fromUserId,
        content,
        timestamp: Date.now()
    };
    messages.push(message);
    return message;
}

function getRecentMessages(limit = 50) {
    return messages.slice(-limit);
}

module.exports = { sendMessage, getRecentMessages };
