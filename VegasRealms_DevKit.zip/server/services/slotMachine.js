function spinSlotMachine() {
    const symbols = ['🍒', '7️⃣', '🔔', '💎', '🍋'];
    const reels = [];
    for (let i = 0; i < 3; i++) {
        reels.push(symbols[Math.floor(Math.random() * symbols.length)]);
    }
    const isWin = reels.every((r) => r === reels[0]);
    return { reels, isWin, payout: isWin ? 100 : 0 };
}

module.exports = { spinSlotMachine };
