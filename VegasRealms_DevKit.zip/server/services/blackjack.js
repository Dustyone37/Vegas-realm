function startBlackjackGame() {
    const suits = ['♠', '♥', '♦', '♣'];
    const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    const deck = [];
    suits.forEach((suit) => ranks.forEach((rank) => deck.push({ rank, suit })));

    const shuffled = deck.sort(() => Math.random() - 0.5);
    const playerHand = [shuffled.pop(), shuffled.pop()];
    const dealerHand = [shuffled.pop(), shuffled.pop()];

    return {
        player: playerHand,
        dealer: [dealerHand[0], { rank: '??', suit: '?' }],
        deckSize: shuffled.length
    };
}

module.exports = { startBlackjackGame };
