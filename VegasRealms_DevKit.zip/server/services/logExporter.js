const admin = require('firebase-admin');
const { Parser } = require('json2csv');
const fs = require('fs');
admin.initializeApp();

const db = admin.firestore();

async function exportAuditLogsToCSV(limit = 100, filePath = './audit_logs.csv') {
    const snapshot = await db.collection('audit_logs')
        .orderBy('timestamp', 'desc')
        .limit(limit)
        .get();
    const data = snapshot.docs.map(doc => doc.data());

    const fields = ['userId', 'eventType', 'eventData', 'timestamp'];
    const parser = new Parser({ fields });
    const csv = parser.parse(data);

    fs.writeFileSync(filePath, csv);
    return { success: true, filePath };
}

async function exportAuditLogsToJSON(limit = 100, filePath = './audit_logs.json') {
    const snapshot = await db.collection('audit_logs')
        .orderBy('timestamp', 'desc')
        .limit(limit)
        .get();
    const data = snapshot.docs.map(doc => doc.data());

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return { success: true, filePath };
}

module.exports = { exportAuditLogsToCSV, exportAuditLogsToJSON };
