const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const TRACKER = 'original_achievements';
const LEADERBOARD = 'leaderboard';

/**
 * Generate top N leaderboard for achievements
 */
async function generateLeaderboard(topN = 10) {
    const snapshot = await db.collection(TRACKER)
        .orderBy('points', 'desc')
        .limit(topN)
        .get();

    const result = [];
    snapshot.forEach(doc => {
        const data = doc.data();
        result.push({ userId: data.userId, points: data.points, tier: data.tier });
    });

    await db.collection(LEADERBOARD).doc('global').set({ updated: Date.now(), leaderboard: result });
    return result;
}
