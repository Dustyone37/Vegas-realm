const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const TRACKER = 'original_achievements';

/**
 * Log progress for seasonal achievements
 */
async function logAchievementProgress(userId, action) {
    const ref = db.collection(TRACKER).doc(userId);
    const existing = await ref.get();

    let data = existing.exists ? existing.data() : { userId, points: 0, tier: 'bronze' };

    const scoreMap = {
        'play_slots': 5,
        'win_blackjack': 10,
        'share_support': 15,
        'refer_friend': 25
    };

    data.points += scoreMap[action] || 0;

    if (data.points >= 100) data.tier = 'gold';
    else if (data.points >= 50) data.tier = 'silver';

    await ref.set(data);
    return { success: true, data };
}
