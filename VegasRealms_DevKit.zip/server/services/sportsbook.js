const axios = require('axios');

async function getSportsOdds() {
    try {
        // Replace this with your real API key and endpoint
        const response = await axios.get('https://api.the-odds-api.com/v4/sports/upcoming/odds', {
            params: {
                apiKey: 'YOUR_API_KEY',
                regions: 'us',
                markets: 'h2h,spreads',
                oddsFormat: 'american'
            }
        });
        return response.data;
    } catch (error) {
        return { error: 'Failed to fetch odds', details: error.message };
    }
}

module.exports = { getSportsOdds };
