const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const USERS = 'users';

/**
 * Set player mode to original or chaos
 */
async function setPlayerMode(userId, mode) {
    if (!['original', 'chaos'].includes(mode)) {
        throw new Error('Invalid mode');
    }
    await db.collection(USERS).doc(userId).update({
        gameMode: mode,
        chaosWristband: mode === 'chaos'
    });
    return { success: true, mode };
}

/**
 * Determine if a player should be visible to another player
 */
async function canSeePlayer(viewerId, targetId) {
    const viewer = await db.collection(USERS).doc(viewerId).get();
    const target = await db.collection(USERS).doc(targetId).get();

    if (!viewer.exists || !target.exists) return false;

    const viewerMode = viewer.data().gameMode;
    const targetMode = target.data().gameMode;

    // Chaos players can see all; original players can only see original
    if (viewerMode === 'chaos') return true;
    return viewerMode === 'original' && targetMode === 'original';
}
