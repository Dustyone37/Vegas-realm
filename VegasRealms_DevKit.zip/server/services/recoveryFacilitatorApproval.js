const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const FACILITATORS = 'recovery_facilitators';

/**
 * Apply for facilitator role
 */
async function applyForFacilitator(userId, statement) {
    await db.collection(FACILITATORS).doc(userId).set({
        userId,
        statement,
        appliedAt: Date.now(),
        status: 'pending'
    });
    return { success: true };
}

/**
 * Approve or deny facilitator
 */
async function reviewFacilitator(userId, status) {
    const ref = db.collection(FACILITATORS).doc(userId);
    await ref.update({ status, reviewedAt: Date.now() });
    return { success: true };
}
