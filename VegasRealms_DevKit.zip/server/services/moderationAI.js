const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();
const ALERT_COLLECTION = 'alerts';
const SCORE_COLLECTION = 'mod_scores';

/**
 * Analyze a chat message for anomaly patterns
 */
function detectAnomaly(message) {
    const suspiciousWords = ['hack', 'cheat', 'rig', 'refund', 'exploit', 'bot'];
    const lower = message.toLowerCase();
    return suspiciousWords.some(word => lower.includes(word));
}

/**
 * Update moderation score for user
 */
async function updateModScore(userId, delta) {
    const ref = db.collection(SCORE_COLLECTION).doc(userId);
    const doc = await ref.get();
    const currentScore = doc.exists ? doc.data().score : 0;
    const newScore = currentScore + delta;

    await ref.set({ score: newScore, lastUpdated: Date.now() });
    return newScore;
}

/**
 * Raise an alert for admin
 */
async function raiseAlert(userId, message, reason) {
    const alert = {
        userId,
        message,
        reason,
        timestamp: Date.now()
    };
    await db.collection(ALERT_COLLECTION).add(alert);
    return { alertRaised: true };
}

/**
 * Moderation pipeline on chat message
 */
async function moderateMessage(userId, message) {
    let result = { flagged: false };

    if (detectAnomaly(message)) {
        await raiseAlert(userId, message, 'Anomaly detected in chat message');
        await updateModScore(userId, 5);
        result = { flagged: true, reason: 'anomaly', scoreIncreased: true };
    } else {
        await updateModScore(userId, 1);  // passive score tracking
    }

    return result;
}

module.exports = {
    moderateMessage,
    updateModScore,
    raiseAlert
};
