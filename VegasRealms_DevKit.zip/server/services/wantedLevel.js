const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

const WANTED_COLLECTION = 'wanted_levels';

/**
 * Increase wanted level based on crime severity
 */
async function increaseWantedLevel(userId, severity = 1) {
    const ref = db.collection(WANTED_COLLECTION).doc(userId);
    const doc = await ref.get();
    const current = doc.exists ? doc.data().level : 0;
    const newLevel = current + severity;

    await ref.set({
        level: newLevel,
        updatedAt: Date.now()
    });
    return newLevel;
}

/**
 * Decay wanted level over time
 */
async function decayWantedLevel(userId) {
    const ref = db.collection(WANTED_COLLECTION).doc(userId);
    const doc = await ref.get();
    if (!doc.exists) return 0;

    const current = doc.data().level;
    const newLevel = Math.max(current - 1, 0);
    await ref.set({
        level: newLevel,
        updatedAt: Date.now()
    });
    return newLevel;
}
