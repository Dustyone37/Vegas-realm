const admin = require('firebase-admin');
admin.initializeApp();

const db = admin.firestore();

async function seed() {
    await db.collection('users').doc('exampleUser').set({
        displayName: 'VegasVIP',
        wallet: 1000,
        vipStatus: true,
        avatar: { hat: 'Top Hat', glasses: 'Gold Frames' },
        inventory: ['PokerChipSet', 'BlackjackCardDeck'],
        gamesPlayed: 10,
        wins: 6,
        losses: 4
    });

    await db.collection('games').doc('sampleGame').set({
        type: 'slot',
        status: 'completed',
        players: ['exampleUser'],
        result: 'win'
    });

    console.log('Seeding complete!');
}

seed().catch(console.error);
