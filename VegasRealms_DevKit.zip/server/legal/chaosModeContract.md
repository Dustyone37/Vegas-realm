# CHAOS MODE AGREEMENT - VEGAS REALMS ONLINE

Welcome to Chaos Mode. This experience is **extreme**, **unfiltered**, and **real stakes**.

By entering Chaos Mode, you agree to the following:

## 🧾 Real Financial Stakes
- If you rob or steal in-game, you are stealing **real money** (capped at 5% of a victim’s balance).
- If you are caught, you may be fined or jailed in **real-time hours** (offline or online).
- Repeated offenses may result in permanent lockout from Chaos Mode.

## 🔒 Legal Responsibility
- All actions are logged and time-stamped.
- You waive liability and agree to pay all real-world damages incurred through abuse of Chaos Mode systems.

## 🎯 Consent to Penalty Enforcement
- You agree to automatic enforcement of:
  - Jail sentences (locked gameplay)
  - Fines (deducted from real balance)
  - Account flagging for bounty or authority targeting

## ✅ Signature Required
Before entry, player must:
1. Read this agreement
2. Digitally sign by entering their account password again

Your signature confirms your full acceptance of the above.

---
By signing, you accept responsibility for your actions in Chaos Mode.
