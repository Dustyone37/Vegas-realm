const express = require('express');
const stripe = require('stripe')('sk_live_your_real_key_here');
const app = express();
app.use(express.json());

app.post('/checkout', async (req, res) => {
  const { email, amount, token } = req.body;
  try {
    const charge = await stripe.charges.create({
      amount,
      currency: 'usd',
      source: token,
      receipt_email: email,
      description: 'Vegas Realms Purchase'
    });
    res.json({ success: true, charge });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(4242, () => console.log('Stripe server running on port 4242'));
