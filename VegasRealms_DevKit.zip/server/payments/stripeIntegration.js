const stripe = require('stripe')('sk_test_key_here');
module.exports = async function processPayment(token, amount) {
  return await stripe.charges.create({
    amount,
    currency: 'usd',
    source: token,
    description: 'Vegas Realms Purchase'
  });
}
