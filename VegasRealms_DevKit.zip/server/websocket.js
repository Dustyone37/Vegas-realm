const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });
let clients = [];

wss.on('connection', (ws) => {
    clients.push(ws);
    console.log('Client connected. Total:', clients.length);

    ws.on('message', (message) => {
        // Broadcast to all other clients
        clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN && client !== ws) {
                client.send(message);
            }
        });
    });

    ws.on('close', () => {
        clients = clients.filter(c => c !== ws);
        console.log('Client disconnected. Remaining:', clients.length);
    });
});

console.log('WebSocket server running on ws://localhost:8080');
