const express = require('express');
const admin = require('firebase-admin');
const bodyParser = require('body-parser');

const authRoutes = require('./api/auth');
const { spinSlotMachine } = require('./services/slotMachine');
const { dealPokerHand } = require('./services/pokerEngine');
const { startBlackjackGame } = require('./services/blackjack');
const { getSportsOdds } = require('./services/sportsbook');

admin.initializeApp();

const app = express();
app.use(bodyParser.json());

app.use('/auth', authRoutes);

app.get('/game/slot', (req, res) => {
    const result = spinSlotMachine();
    res.send(result);
});

app.get('/game/poker', (req, res) => {
    const hand = dealPokerHand();
    res.send({ hand });
});

app.get('/game/blackjack', (req, res) => {
    const game = startBlackjackGame();
    res.send(game);
});

app.get('/sportsbook/odds', (req, res) => {
    const odds = getSportsOdds();
    res.send(odds);
});
    const hand = dealPokerHand();
    res.send({ hand });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
