const nodemailer = require('nodemailer');
module.exports = async function sendFeedback(from, message) {
  const transporter = nodemailer.createTransport({ service: 'gmail', auth: { user: 'dev@vegasrealms.com', pass: 'APP_PASSWORD' }});
  await transporter.sendMail({ from, to: 'feedback@vegasrealms.com', subject: 'Alpha Feedback', text: message });
}
