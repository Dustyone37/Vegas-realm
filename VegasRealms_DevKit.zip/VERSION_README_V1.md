# Vegas Realms Online – DevKit V1.0

## 🎰 Overview
This is the official Developer Kit for **Vegas Realms Online**, versioned at V1.0. It includes all core systems, mockups, assets, blueprints, and documentation to begin UE5-based development of the real-money multiplayer casino game.

---

## 🧱 Included Features (V1.0):
1. 🎮 **Casino Floor Mockup** – fully mapped out in `/Maps/CasinoFloor.umap`
2. 🕹 **Slot, Poker, Blackjack, Roulette** tables with real .FBX placeholders
3. 🧍 **Larry-style Avatar** – skeletal mesh, animations, emotes
4. 📦 **Organized Asset Folders** – standard naming conventions
5. ⚙️ **Interactive Blueprints** – slot triggers, dealer emotes, win effects
6. 🎞 **Animation Hooks** – win animations, walking loops, idle blending
7. 📘 **Full Developer Documentation**

---

## 🔧 Technical Stack
- Engine: **Unreal Engine 5**
- Assets: FBX/PBR, modular
- Blueprints: Actor/Trigger/Montage-based
- Interactions: Keypress-based with animation bridges
- Ready for: Multiplayer integration, UI overlays, marketplace/economy features

---

## 📂 Key Directories
```
/client/UE5/CasinoFloor/
/client/components/
/client/firebase-config.js
/server/services/
/Blueprints/
/Meshes/
/Animations/
```

---

## 🗂 V1.0 Export Includes:
- All source folders
- All .fbx and .uasset placeholder files
- Naming conventions doc
- Readme + setup instructions

