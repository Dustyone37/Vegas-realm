# Firestore Schema

```json
{
  "users": {
    "uid": {
      "displayName": "string",
      "wallet": "number",
      "vipStatus": "boolean",
      "avatar": "map",
      "inventory": "array",
      "gamesPlayed": "number",
      "wins": "number",
      "losses": "number"
    }
  },
  "games": {
    "gameId": {
      "type": "string",
      "status": "string",
      "players": "array",
      "results": "map",
      "timestamp": "timestamp"
    }
  },
  "transactions": {
    "txnId": {
      "user": "uid",
      "amount": "number",
      "currency": "string",
      "type": "string",
      "timestamp": "timestamp"
    }
  }
}
```